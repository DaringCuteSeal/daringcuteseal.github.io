# CATATAN: Letakkan icon archive.png ke direktori yang sama dengan todo.py
import customtkinter as ctk
from dataclasses import dataclass 
from typing import Any, Callable
from random import choice
from PIL import Image

os = ctk.os

# Constants
TAG_COLORS = ["#AD3A3A", "#D77E48", "#C1B540", "#C1B540", "#529EE5", "#6852E5", "#E079E5", "#E579AF", "#E58479", "#379779", "#743796", "#88427A"]

IMG_ARCHIVE_PATH = os.path.join(os.getcwd(), "archive.png")
IMG_ARCHIVE = ctk.CTkImage(Image.open(IMG_ARCHIVE_PATH))

# Tabs Management

@dataclass
class TabView(ctk.CTkTabview):
    master: Any

    def __post_init__(self):
        super().__init__(self.master)

    def configure_grid(self):
        self.grid(column=0, row=0, sticky="nswe", padx=10, pady=10)    

    def create_tabs(self) -> ctk.CTkFrame:
        return self.add("Tasks")               


# Tasks Management

## Dataclasses

@dataclass
class TaskTag:
    """
    A task tag.
    """
    name: ctk.StringVar
    color: str

    @classmethod
    def new(cls, name: str, color: str) -> 'TaskTag':
        name_var = ctk.StringVar()
        name_var.set(name)
        return TaskTag(name_var, color)

@dataclass
class Task:
    """
    A task.
    """
    desc: ctk.StringVar
    tag: TaskTag
    due: ctk.StringVar
    idx: ctk.IntVar

    @classmethod
    def new(cls, desc: str, tag: TaskTag, due: str, idx: int = 0) -> 'Task':
        return Task(ctk.StringVar(value=desc), tag, ctk.StringVar(value=due), ctk.IntVar(value=idx))
    

class TasksStorage:
    """
    Management of tasks and tags list.
    """
    tasks: list[Task] = []
    tags: list[TaskTag] = []

    def add_new_task(self, desc: str, tag_name: str, due_date: str, idx: int = 0) -> Task:
        tag = self.select_or_create_tag(tag_name)
        task = Task.new(desc, tag, due_date, idx)
        self.tasks.append(task)
        return task # return a reference to task while also adding it to our storage
    
    def delete_task_by_idx(self, idx: int):
        self.tasks.pop(idx)

    def select_or_create_tag(self, term: str) -> TaskTag:

        if (tag := self.lookup_tag(term)) is not None:
            return tag
        else:
            return TaskTag.new(term, self.get_random_tag_color())

    def lookup_tag(self, term: str) -> TaskTag | None:
        for tag in self.tags:
            if tag.name == term:
                return tag
        return None

    def get_random_tag_color(self) -> str:
        return choice(TAG_COLORS)

    def serialize_to_str(self):
        pass

    def serialize_from_str(self):
        pass


class TaskWidgetGroup(ctk.CTkFrame):
    """
    Generates a single task display, contained by a frame. When deleting, destroy with TaskWidgetGroup.destroy().

    """
    IDX_COL = 0
    DESC_COL = 1
    TAG_COL = 2
    DUE_COL = 3
    CHECKBOX_COL = 4
    ARCHIVE_COL = 5

    OVERDUE_BG_COLOR = "#9C2727"
    DUE_BG_COLOR = "#333652"


    def __init__(self, master, task: Task, row: int):
        super().__init__(master)
        self.configure_columns()
        self.grid(column=0, row=row, sticky="we")

        self.index_label = self.attach_index_label(task)
        self.desc_label = self.attach_desc_label(task)
        self.due_label = self.attach_due_label(task) # XXX used implicitly by self.set_due!
        self.tag_label  = self.attach_tag_label(task)
        self.checkbox = self.attach_checkbox(lambda: self.checkbox_callback_handler(task))
        
    def checkbox_callback_handler(self, task: Task):
        if self.checkbox.get():
            self.set_bg_dark()
        else:
            self.set_bg_normal()

    def set_bg_dark(self):
        self.configure(fg_color="#9B9B9B")

    def set_bg_normal(self):
        self.configure(fg_color="#CFCFCF")

    def archive_callback_handler(self, task: Task):
        self.destroy()


    def set_due(self, due: bool):
        """
        Update due status.
        """
        # XXX UNIMPLEMENTED
        if due:
            self.due_label.config(fg_color=self.OVERDUE_BG_COLOR)
        else:
            self.due_label.config(fg_color=self.DUE_BG_COLOR)

    def configure_columns(self):
        self.columnconfigure(self.IDX_COL, weight=1)
        self.columnconfigure(self.DESC_COL, weight=5)
        self.columnconfigure(self.TAG_COL, weight=1)
        self.columnconfigure(self.DUE_COL, weight=2)
        self.columnconfigure(self.CHECKBOX_COL, weight=1)
        self.columnconfigure(self.ARCHIVE_COL, weight=1)

    def attach_index_label(self, task: Task) -> ctk.CTkLabel:
        label = ctk.CTkLabel(self, textvariable = task.idx)
        label.grid(column=self.IDX_COL, row=0, padx=5)
        return label

    def attach_tag_label(self, task: Task) -> ctk.CTkLabel:
        label = ctk.CTkLabel(self, textvariable = task.tag.name, fg_color=task.tag.color)
        label.grid(column=self.TAG_COL, row=0, padx=5)
    def attach_desc_label(self, task: Task) -> ctk.CTkLabel:
        label = ctk.CTkLabel(self, textvariable=task.desc)
        label.grid(column=self.DESC_COL, row=0, padx=5)
        return label

    def attach_due_label(self, task: Task) -> ctk.CTkLabel:
        label = ctk.CTkLabel(self, textvariable=task.due, fg_color=self.DUE_BG_COLOR, text_color="#FFFFFF")
        label.grid(column=self.DUE_COL, row=0, padx=5)
        return label
    
    def attach_checkbox(self, callback: Callable[..., None]) -> ctk.CTkCheckBox:
        checkbox = ctk.CTkCheckBox(self, text="Mark done", command=callback)
        checkbox.grid(column=self.CHECKBOX_COL, row=0, padx=5)
        return checkbox

    def attach_archive_btn(self, callback: Callable[..., None]) -> ctk.CTkButton:
        btn = ctk.CTkButton(self, text="Archive", command=callback, image=IMG_ARCHIVE)
        btn.grid(column=self.ARCHIVE_COL, row=0, padx=5)
        return btn

class TasksRenderer:
    """
    Helper class for rendering tasks on the `Tasks` tab.
    Uppermost interface to manage tasks. ONLY attach the methods here as a direct button callback.
    """
    def __init__(self, frame: ctk.CTkFrame, storage: TasksStorage):
        self.frame = frame
        self.frame.grid(sticky="ew")
        self.storage = storage
        self.child_frames: list[TaskWidgetGroup] = [] # list of TaskWidgetGroup

        self.tasks_status = ctk.CTkLabel(self.frame, text="")
        self.tasks_status.grid(column=0, row=0)

        self.reconfigure_layout()


    def get_task_tags(self) -> list[TaskTag]:
        return self.storage.tags

    def insert_task(self, desc: str, tag_name: str, due_date: str, idx: int):

        task = self.storage.add_new_task(desc, tag_name, due_date, idx)
        frame = TaskWidgetGroup(self.frame, task, len(self.storage.tasks))
        self.child_frames.append(frame)
        frame.attach_archive_btn(lambda: self.delete_task(idx - 1))



    def reconfigure_layout(self):
        if not self.storage.tasks:
            self.show_no_tasks()
        else:
            self.tasks_status.destroy()
            
    def show_no_tasks(self):
        self.tasks_status = ctk.CTkLabel(self.frame, text="No tasks")
        self.frame.columnconfigure(0, weight=1)
        self.frame.rowconfigure(0, weight=1)

    def delete_task(self, idx: int):
        self.storage.delete_task_by_idx(idx)
        self.child_frames[idx].destroy()
        self.child_frames.pop(idx)
        self.reconfigure_layout()
        print(self.storage.tasks)

    def get_tasks_count(self) -> int:
        return len(self.storage.tasks)


## Helper Classes
class TasksInputMgr:
    """
    Helper class for displaying the new task input area. Depends on `TasksRenderer`.

    """

    TEXTBOX_LABEL_COL = 0
    TEXTBOX_COL = 1
    TAG_SEL_COL = 2
    DUE_ENTRY_COL = 3
    ADD_BTN_COL = 4

    def __init__(self, frame: ctk.CTkFrame, renderer: TasksRenderer):
        """
        Initialize the input area. `frame` passed should be the uppermost frame area dedicated to the input area.
        """
        self.frame = frame
        self.renderer = renderer
        self.tmp_tags_list: list[TaskTag] = []
        self.configure_layout(self.frame)

        self.textbox_label = self.attach_textbox_label(self.frame)
        self.textbox = self.attach_textbox(self.frame)
        self.tag_options = self.attach_tag_options(self.frame)
        self.due_entry = self.attach_due_entry(self.frame)
        self.add_btn = self.attach_add_btn(self.frame, self.add_new_todo_handler)

    def add_new_todo_handler(self):
        task_desc = self.textbox.get()
        if not task_desc:
            return
            
        task_tag = self.tag_options.get()
        if not task_tag:
            task_tag = "No tag"

            
        task_due_date = self.due_entry.get()
        if not task_due_date:
            task_due_date = " No due "

            
        self.renderer.insert_task(task_desc, task_tag, " " + task_due_date + " ", self.renderer.get_tasks_count()+1)
        self.reset_input()

    def reset_input(self):
        self.textbox.delete(0, 1000000)
        self.tag_options.delete(0, 1000000)
        self.due_entry.delete(0, 10000)

    def update_tags_list(self):
        self.tmp_tags_list = self.renderer.get_task_tags()

    def configure_layout(self, frame: ctk.CTkFrame):
    
        frame.columnconfigure(self.TEXTBOX_LABEL_COL, weight=1)
        frame.columnconfigure(self.TEXTBOX_COL, weight=8)
        frame.columnconfigure(self.TAG_SEL_COL, weight=1)
        frame.columnconfigure(self.DUE_ENTRY_COL, weight=1)
        frame.columnconfigure(self.ADD_BTN_COL, weight=1)

    def attach_textbox_label(self, master: ctk.CTkFrame) -> ctk.CTkLabel:
        label = ctk.CTkLabel(master, text="Add new: ")
        label.grid(column=self.TEXTBOX_LABEL_COL, row=1, padx=2, pady=2, sticky="nswe")
        return label

    def attach_textbox(self, master: ctk.CTkFrame) -> ctk.CTkEntry:
        textbox =  ctk.CTkEntry(master, placeholder_text="Task description..")
        textbox.grid(column=self.TEXTBOX_COL, row=1, padx=2, pady=2, sticky="nswe")
        return textbox
    
    def attach_tag_options(self, master: ctk.CTkFrame) -> ctk.CTkOptionMenu:
        entry = ctk.CTkEntry(master, placeholder_text="Tag..")
        entry.grid(column=self.TAG_SEL_COL, row=1, padx=2, pady=2, sticky="nswe")
        return entry

    def attach_due_entry(self, master: ctk.CTkFrame) -> ctk.CTkEntry:
        entry = ctk.CTkEntry(master, placeholder_text="Due..")
        entry.grid(column=self.DUE_ENTRY_COL, row=1, padx=2, pady=2, sticky="nswe")
        return entry

    def attach_add_btn(self, master: ctk.CTkFrame, callback: Callable[..., None]) -> ctk.CTkButton:
        btn = ctk.CTkButton(master, text="Add Task", command=callback)
        btn.grid(column=self.ADD_BTN_COL, row=1, padx=2, pady=2, sticky="nswe")
        return btn

        
class TasksTab():
    """
    Manager for the `Tasks` tab.
    """

    def __init__(self, master_frame: ctk.CTkFrame):
        self.master_frame = master_frame
        self.configure_layout_weights(self.master_frame)

        self.tasks_frame = self.attach_tasks_frame(self.master_frame)
        self.renderer = TasksRenderer(self.tasks_frame, TasksStorage())

        self.tasks_input_frame = self.attach_input_frame(self.master_frame)
        self.tasks_input_mgr = TasksInputMgr(self.tasks_input_frame, self.renderer)


    def attach_tasks_frame(self, master: ctk.CTkFrame) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(master)
        frame.grid(column=0, row=0, padx=5, pady=5, sticky="wenss")
        return frame
    
    def attach_input_frame(self, master: ctk.CTkFrame) -> ctk.CTkFrame:
        """
       Configure the input frame.
       """
        frame = ctk.CTkFrame(master, height=30)
        frame.grid(column=0, row=1, padx=5, pady=5,  sticky="wens")
        return frame

    def configure_layout_weights(self, master: ctk.CTkFrame):
        master.columnconfigure(0, weight=1)
        master.rowconfigure(0, weight=3000)
        master.rowconfigure(1, weight=1)
        



# Uppermost app

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("light")

        tab = TabView(self)
        self.tab_tasks = tab.create_tabs()
        tab.configure_grid()

        self.tab_tasks.rowconfigure(0, weight=1)
        
        self.input_frame = ctk.CTkFrame(self.tab_tasks, height=30)
        self.input_frame.grid(column=0, row=1, sticky="we")

    

        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        self.add_wdgt_tasks_tab(self.tab_tasks)

    def add_wdgt_tasks_tab(self, frame: ctk.CTkFrame ) -> TasksTab:
        return TasksTab(frame)
        

    def add_wdgt_archive_tab(self):
        pass


app = App()
app.mainloop()

